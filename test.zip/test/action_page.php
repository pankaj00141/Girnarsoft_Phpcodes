<html>
<body>

Welcome   <b> Mr.</b> <?php   echo $_POST["firstname"] ; ?>
<?php echo "  ".$_POST["lastname"]; ?> <br>
 <h4>Your  data  is received and the details entred by you is  </h4>
  <b>city</b>      :      <?php   echo $_POST["city"]; ?>  <br> <br>
  <b>Gender</b>    :      <?php   echo $_POST["gender"];?>  <br> <br>
<b>State </b>  :        <?php   echo $_POST["State"]; ?>  <br>  <br>
<b> The Message we received is </b> <br>   <?php  echo $_POST["message"];  ?>

<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "myDB";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$stmt = $conn->prepare("INSERT INTO Registration (firstname, lastname,city ,Gender ,state ,Message) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $firstname, $lastname, $city,$Gender ,$state , $Message);

$firstname = $_POST["firstname"];
$lastname = $_POST["lastname"] ;
$city  =  $_POST["city"] ;
$Gender =  $_POST["gender"] ;
$state =   $_POST["State"] ;
$Message  =  $_POST["message"] ;

$stmt->execute();

echo "Your Record is notified in database succesfully";

$stmt->close();
$conn->close();
?>

</body>
</html>
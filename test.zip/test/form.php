

<html>

<head>
    <title> Registration form </title>
</head>
<body>
<h2> Registration form</h2>
<p>
   <b> Enter your Details</b> <br>

</p>
<form method = "post" action="action_page.php" >
    <fieldset>
    first name :   &nbsp   <input type = "text" name ="firstname" autofocus required   pattern="[A-Za-z]{1,15}" title="upto 10 letter, characters only" maxlength="10"> <br>

        last name :    &nbsp     <input type ="text" name = "lastname" autofocus   pattern="[A-Za-z]{1,15}" title="upto 10 letter characters only " required maxlength="10"> <br>
    City :    &nbsp&nbsp&nbsp       <input type = "text" name="city" autofocus  pattern="[A-Za-z]{1,15}" title="upto 10 letter characters only " required maxlength="10"> <br>
    Gender: <br>
        <input type = "radio" name ="gender" value = "Male"  autofocus> Male <br>
         <input type = "radio" name ="gender" value = "female" autofocus> female <br>
        state :  &nbsp &nbsp
        <select name="State" required>
            <option value="Rajasthan">Rajasthan</option>
            <option value="Haryana">Haryana</option>
            <option value="gujarat">Gujarat</option>
            <option value="Maharashtra">Maharashtra</option>
        </select>   <br> <br>
         Message  :   <br>
        <textarea name="message" rows="8" cols="50" required maxlength="50">
         Enter your hobbies
        </textarea> <br> <br>
       <input type="submit" value="Submit form"> <br>
    </fieldset>
</form>


</body>
</html>
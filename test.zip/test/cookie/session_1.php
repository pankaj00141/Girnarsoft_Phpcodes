<?php

session_start();
$_SESSION['uname'] =  "pankaj" ;
$_SESSION['color'] =   "Black" ;


echo $_SESSION['uname'];



?>
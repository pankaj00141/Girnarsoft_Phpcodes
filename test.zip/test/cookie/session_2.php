<?php

session_start();
echo $_SESSION['uname']; <br>
echo $_SESSION['COLOR'];



echo  "your session data will expire after ". session_cache_expire(). "minutes ;" ;
echo  "   your id is ".session__id() ;


?>


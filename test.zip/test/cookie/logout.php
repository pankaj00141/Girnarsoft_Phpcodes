<?php


if(!isset($_COOKIE["login"]))
    header("location:form.php");

setcookie("login","", time() -1 );
header("location:index.php")




?>
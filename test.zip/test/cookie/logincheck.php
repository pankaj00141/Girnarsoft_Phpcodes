<?php
if(!isset($_COOKIE["login"]))
    header("location:form.php");
?>



<H2> IF YOU ARE ON THIS PAGE MEANS YOU ARE NOW LOGGED IN AND YOUR COOKIE IS SET</H2>


<br />
<a href ="logout.php"> LOGOUT</a>


<table border ='0'  align = "center" />
    <form method ='post' action="cookie_val.php">
        <tr>
            <td>
                Login Name
            </td>
            <td>
                <input type ="text" name = "uname" size="20" autofocus required   pattern="[A-Za-z]{1,15}" title="upto 10 letter, characters only" maxlength="10"/>

            </td>
        </tr>
        <tr>
            <td>
                Password
            </td>
            <td>
                <input type ="password" name = "upassword" size="20"autofocus required   pattern="[A-Za-z]{1,15}" title="upto 10 letter, characters only" maxlength="10" />

            </td>
        </tr>
           <td colspan ="2"><input type = "checkbox" value = "1" name = "remember"/>  Keep me Logged in</td>
        <tr>
            <td colspan="2" align ='center'>
                <input type ="submit" value = "Login" name ="submit" />
                &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;
                <input type="reset" value = "clear" />

            </td>
        </tr>
        <tr>
            <td colspan ="2" align ="center" >
                <?php
                  if(isset($_REQUEST["err"]))
                    echo "Invalid username and password " ;
                ?>
            </td>
        </tr>
    </form>
</table>
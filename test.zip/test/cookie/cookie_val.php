<?php

$Cser = mysqli_connect("localhost","root","root","myDB") or die ("Server connection failed". mysqli_error() );

echo " coonection established";
$uname = $_REQUEST["uname"];
$upassword = $_REQUEST["upassword"];

$s =  " select *  from test where uname = '".$uname."'and upassword ='".$upassword."' " ;

$result = mysqli_query($Cser,$s);
$count = mysqli_num_rows($result);
echo $count ;

if($count > 0)
{
    if(isset($_REQUEST["remember"]) && $_REQUEST["remember"]== 1 )
       setcookie("login","1",time()+ 365*24*60*60);
       else
        setcookie("login", "1");
       header("location:index.php");
 }
else
{
    header("location:form.php");
}

?>
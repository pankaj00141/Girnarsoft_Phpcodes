<?php
 if(!isset($_COOKIE["login"]))
     header("location:form.php");
?>




<h2>   Welcome to cookie validation for login  </h2>
<br />
<a href ="logout.php"> LOGOUT</a>



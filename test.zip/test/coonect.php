<?php
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);


$conn = mysqli_connect('127.0.0.1','root','root');


// Check connection
if (mysqli_connect_error()) {
die("Database connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";
<br>
$conn->close();
    ?>
/*
$sql = "CREATE TABLE Registration (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstname VARCHAR(30)  NOT NULL,
lastname VARCHAR(30) NOT NULL,
city VARCHAR(30) NOT NULL,
Gender VARCHAR(30) NOT NULL,
State VARCHAR(30) NOT NULL,
Message VARCHAR(2500) NOT NULL"
;
if (mysqli_query($conn, $sql)) {
    echo "Registration table  created successfully";
} else {
    echo "Error creating table " . mysqli_error($conn);
}
$conn->close();
*/

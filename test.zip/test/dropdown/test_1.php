<?php
$conn = mysqli_connect("localhost", "root", "root", "myDB") or die ("Server connection failed" . mysqli_connect_error());
$checkbox1 = $_POST['chk1'];
echo sizeof($checkbox1);

if ($_POST["Submit"] == "Submit") {

    for ($i = 0; $i < sizeof($checkbox1); $i++) {
        echo " " . $checkbox1[$i] . " ";
        $query = "INSERT INTO check1 (Name) VALUES ('" . $checkbox1[$i] . "')" . "/n";
        mysqli_query($conn, $query);
    }
    echo " Record is inserted ";
}


//echo " I RAN" ;
/*$stmt = $conn->prepare("INSERT INTO cars (TATA,PORCHE,NANO) VALUES (?, ?, ?)");
//echo  " 23" ;
$stmt->bind_param("sss", $tata, $porche, $nano,);
//echo  "I am hehe" ;
$tata = $_POST["TATA"];
$porche = $_POST["PORCHE"] ;
$nano  =  $_POST["NANO"] ;

$stmt->execute();

echo "Your Record is notified in database succesfully";

$stmt->close();
$conn->close();   */
?>

<html>
<body>
<body bgcolor ="pink">
<h3>Insert value from checkbox <h3/>
    <form action ="test_1.php" method ='post'>
        <input type="checkbox" name="chk1[]" value ='TATA'> TATA <br>
        <input type="checkbox" name="chk1[]" value ='SEDAN'> SEDAN <br>
        <input type="checkbox" name="chk1[]" value ='NANO'> NANO <br>
        <input type="checkbox" name="chk1[]" value ='TOYOTA'> TOYOTA <br>
        <input type="checkbox" name="chk1[]" value ='SEED'> SEED <br>

        <br>
        <input type ="submit" name="Submit"  value ="Submit">
        </form>
    </body>
<html>







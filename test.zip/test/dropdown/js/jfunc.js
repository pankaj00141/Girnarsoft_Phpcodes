function hide_element ( element , speed )
{
$(element).hide(speed) ;

}


function toggle_element(element , speed)
{
 $(element).toggle(speed) ;
}
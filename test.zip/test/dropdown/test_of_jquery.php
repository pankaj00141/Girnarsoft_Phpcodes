<html>
<head>
    <script type ="text/javascript" src = "js/jquery.js"> </script>
    <script type ="text/javascript" src = "js/jfunc.js"> </script>
</head>
<body>

<p id ="paragraph"> Click here to hide me  </p>
<input type = "button"  value ="Toggle" onclick="toggle_element('#paragraph',1000);"  />

</body>

</html>

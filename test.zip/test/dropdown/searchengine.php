<html>
<head>
    <title> Search Engine In PHP</title>
</head>

<body>
<form action="searchengine.php"  method="get">
      Search Engine : <input type="text" name="value" placeholder="Search Anything here">
                      <input type ="submit" name="search" value="Search Now">

</form>
<hr>
</body>
</html>

<?php

    $conn =mysqli_connect("localhost","root","root","myDB");
       if(isset($_GET['search']))
       {
        $search_value = $_GET['value'];
        $query  = "Select * from sites where site_keyword like '%$search_value%' ";
        $run  =mysqli_query($conn,$query);

        while($row = mysqli_fetch_array($run))
        {
            $title = $row['site_title'] ;
            $link =  $row['site_link'] ;
            $desc =  $row['site_desc'] ;
           echo "<h3> $title </h3> <a href ='$link'>$link</a>  <p>$desc</p> " ;
        }
    }
?>